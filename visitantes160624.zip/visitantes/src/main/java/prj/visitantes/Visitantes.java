/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package prj.visitantes;

import formularios.frmLogin;

/**
 *
 * @author Vitor
 */
public class Visitantes {

    public static void main(String[] args) {
        frmLogin meuLogin = new frmLogin();
        meuLogin.setLocationRelativeTo(null);
        meuLogin.setVisible(true);
    }
}
